<?php

function titans_spawn_titan(){
	//we need to make a Titan appear on an edge of the World Map.
	
	//Get X and Y co-ordinates of a random location on the edge of the world map.
	$x = e_rand(1,get_module_setting("worldmapsizeX","worldmapen"));
	$y = e_rand(1,get_module_setting("worldmapsizeY","worldmapen"));
	$max = e_rand(0,1);
	$drop = e_rand(0,1);
	if ($drop){
		if ($max){
			$x = 1;
		} else {
			$x = get_module_setting("worldmapsizeX","worldmapen");
		}
	} else {
		if ($max){
			$y = 1;
		} else {
			$y = get_module_setting("worldmapsizeY","worldmapen");
		}
	}
	$location = $x.",".$y.",1";
	
	//Create a Titan's battle array.
	$titan = array();
	$titan['creaturename']="Titan";
	$titan['creatureweapon']="Unstoppable Force";
	$titan['creaturelevel']=20;
	$titan['creaturegold']=1000;
	$titan['creatureexp']=0;
	$titan['creaturehealth']=10000000;
	$titan['creatureattack']=10;
	$titan['creaturedefense']=10;
	$titan['multiplayer']=1;
	
	//Set the Titan's destination - choose a random city, get its World Map values.
	$cities=array();
	$sql = "select * from ".db_prefix("cityprefs");
	$result=db_query($sql);
	$numcities = db_num_rows($result);
	for ($i = 0; $i < $numcities; $i++){
		$row = db_fetch_assoc($result);
		$cities[]=$row;
	}
	$targetkey = e_rand(0,($numcities-1));
	$titan['destination']['cityid']=$cities[$targetkey]['cityid'];
	$titan['destination']['cityname']=$cities[$targetkey]['cityname'];
	$titan['destination']['x']=get_module_setting($cities[$targetkey]['cityname']."X","worldmapen");
	$titan['destination']['y']=get_module_setting($cities[$targetkey]['cityname']."Y","worldmapen");
	
	//write the titan back to the database
	$battlelog = array();
	$battlelog = serialize($battlelog);
	$creature = serialize($titan);
	
	$sql = "INSERT INTO ".db_prefix("titans")." (location,creature,battlelog) VALUES ('$location','$creature','$battlelog')";
	db_query($sql);
}

function titans_move_titan($id){
	//move a Titan one square towards its target
}

function titans_set_titan($id,$creature,$log=false){
	//Update a titan
	$creature = serialize($creature);
	if (!$log){
		$sql = "UPDATE ".db_prefix("titans")." SET creature='$creature' WHERE id='$id'";
	} else {
		$battlelog = serialize($log);
		$sql = "UPDATE ".db_prefix("titans")." SET creature='$creature', battlelog='$battlelog' WHERE id='$id'";
	}
	db_query($sql);
}

function titans_get_titan($id){
	$sql = "SELECT location,creature,battlelog FROM " . db_prefix("titans") . " WHERE id = '$id'";
	$result = db_query($sql);
	$row=db_fetch_assoc($result);
	$row['creature'] = unserialize($row['creature']);
	$row['battlelog'] = unserialize($row['battlelog']);
	if (!isset($row['battlelog']['combatants'])){
		$row['battlelog']['combatants']=array();
	}
	return $row;
}

function titans_load_battle($id){
	global $session,$badguy,$battle;
	$titan = titans_get_titan($id);
	restore_buff_fields();
	$creature = $titan['creature'];
	$creature['titaninfo']['badguy']['hpstart'] = $creature['creaturehealth'];
	$creature['titaninfo']['player']['hpstart'] = $session['user']['hitpoints'];
	$badguy = $creature;
	calculate_buff_fields();
	$session['user']['badguy']=createstring($badguy);
	$battle = true;
	return($titan);
}

function titans_save_battle($id,$creature,$battlelog){
	global $session,$badguy,$battle;
	$battlelog = titans_update_log($id,$badguy,$battlelog);
	titans_set_titan($id,$badguy,$battlelog);
}

function titans_show_comrades($battlelog){
	global $session;
	if (count($battlelog['combatants'])>1){
		require_once "modules/combatbars.php";
		foreach($battlelog['combatants'] AS $acctid=>$vals){
			if ($acctid!=$session['user']['acctid']){
				combatbars_showbar($vals['hp'],$session['user']['maxhitpoints'],"`2Comrade: `0".$vals['name']);
			}
		}
	}
}

function titans_update_log($id,$creature,$battlelog){
	global $session;
	$titandamage = $creature['titaninfo']['badguy']['hpstart'] - $creature['creaturehealth'];
	$playerdamage = $creature['titaninfo']['player']['hpstart'] - $session['user']['hitpoints'];
	$battlelog['log'][] = array(
		"tdmg"=>$titandamage,
		"pdmg"=>$playerdamage,
		"thp"=>$creature['creaturehealth'],
		"php"=>$session['user']['hitpoints'],
		"pid"=>$session['user']['acctid'],
	);
	$battlelog['combatants'][$session['user']['acctid']]['hp']=$session['user']['hitpoints'];
	$battlelog['combatants'][$session['user']['acctid']]['name']=$session['user']['name'];
	$battlelog['combatants'][$session['user']['acctid']]['lastlog']=count($battlelog['log']);
	debug($battlelog);
	return ($battlelog);
}

function titans_show_log($battlelog){
	global $session;
	$lastlog = $battlelog['combatants'][$session['user']['acctid']]['lastlog'];
	$end = count($battlelog['log']);
	if ($lastlog < $end){
		output("`0`bBattle Log:`b`n");
		for ($i=$lastlog; $i<$end; $i++){
			$id = $battlelog['log'][$i]['pid'];
			$name = $battlelog['combatants'][$id]['name'];
			output("`0%s`0 dealt `2%s`0 damage, and took `4%s`0 damage`n",$name,$battlelog['log'][$i]['tdmg'],$battlelog['log'][$i]['pdmg']);
		}
		output("`n");
	}
}

?>