<?php

global $session,$badguy,$battle;
require_once "modules/titans/lib/lib.php";

page_header("Titans!");

$titan = titans_load_battle(1);
titans_show_log($titan['battlelog']);

if ($battle){
	include_once("battle.php");
	require_once("lib/fightnav.php");
	fightnav(true,true,"runmodule.php?module=titans&titanop=beta");
}

titans_save_battle(1,$titan['creature'],$titan['battlelog']);
titans_show_comrades($titan['battlelog']);

debug(strlen(serialize($titan['battlelog'])));

addnav("Village","village.php");

page_footer();

?>