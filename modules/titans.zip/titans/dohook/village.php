<?php

addnav("Beta Testing");
addnav("Battle the Titan!","runmodule.php?module=titans&titanop=beta&titanid=1");

?>