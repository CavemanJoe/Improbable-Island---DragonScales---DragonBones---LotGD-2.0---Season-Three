<?php

global $session;

$hid = httpget('hid');
$rid = httpget('rid');
require_once "modules/improbablehousing/lib/lib.php";
$house = improbablehousing_gethousedata($hid);

page_header("Keys and Locks");

$toggle = httpget('toggle');
if ($toggle=="master"){
	if ($house['data']['locked']==1){
		$house['data']['locked']=0;
	} else {
		$house['data']['locked']=1;
	}
} else if ($toggle){
	if ($house['data']['rooms'][$toggle]['locked']==1){
		$house['data']['rooms'][$toggle]['locked']=0;
	} else {
		$house['data']['rooms'][$toggle]['locked']=1;
	}
}

if ($house['data']['locked']){
	$masterlock = "`4Locked`0";
	addnav("Master Lock");
	addnav("Open the Master Lock","runmodule.php?module=improbablehousing&op=locks&toggle=master&hid=$hid&rid=$rid");
} else {
	$masterlock = "`2Unlocked`0";
	addnav("Master Lock");
	addnav("Close the Master Lock","runmodule.php?module=improbablehousing&op=locks&toggle=master&hid=$hid&rid=$rid");
}

output("Locking a room will ensure people can't get in, but people who are currently in those rooms are free to leave.  Here's the status of your locks:`n`n");
output("Dwelling entrance: %s`n",$masterlock);

foreach($house['data']['rooms'] AS $rkey=>$rvals){
	if ($rkey!=0){
		addnav("Rooms");
		if ($rvals['locked']){
			addnav(array("Unlock %s",$rvals['name']),"runmodule.php?module=improbablehousing&op=locks&toggle=$rkey&hid=$hid&rid=$rid");
			output("`0%s`0: `4Locked`0`n",$rvals['name']);
		} else {
			addnav(array("Lock %s",$rvals['name']),"runmodule.php?module=improbablehousing&op=locks&toggle=$rkey&hid=$hid&rid=$rid");
			output("`0%s`0: `2Unlocked`0`n",$rvals['name']);
		}
	}
}

improbablehousing_sethousedata($house);
improbablehousing_bottomnavs($house,$rid);
page_footer();

?>