<?php

/*

IItems:
wood
stone

Actions:
Logging
Stonecutting
Masonry
Carpentry

Buildings:
Land Registry
Locksmith

Log cabins and rubble-mason houses.
Houses with a high concentration of stone vs wood will retain a more constant temperature, meaning that the owner gets better sleep and a more generous Stamina boost.

Building a house for the first time should take around 1,000% Stamina.  Chance of injury for building house while tired.

COST STRUCTURE
(assuming newbie action levels)

Land Registry:
100 Cigarettes per initial structure
Building:
500% Stamina to create an initial 10 square foot cabin or stone house, along with 50 building materials of either stone or wood.
50% Stamina for each additional square foot of space.
(make the initial cost of each iteration around 5% or so, for granularity, with additional options to work for 5/10/25 turns / until tired / etc)
50% Stamina to create a wall subdividing a room into two rooms.

*/



//done?
function improbablehousing_getnearbyhouses($loc){
	global $session;
	$sql = "SELECT id,ownedby,data FROM " . db_prefix("improbabledwellings") . " WHERE location = '$loc'";
	//$result = db_query_cached($sql,"housing/housing_location_".$loc);
	//todo: cache this query, or rather, invalidate the cache properly after staking a claim
	$result = db_query($sql);
	$n = db_num_rows($result);
	
	if (!$n){
		return null;
	} else {
		$r = array();
		for ($i=0;$i<$n;$i++){
			$row=db_fetch_assoc($result);
			$house = array(
				"id"=>$row['id'],
				"ownedby"=>$row['ownedby'],
				"data"=>unserialize($row['data']),
			);
			$r[]=$house;
		}
	}
	return $r;
}

//done?
function improbablehousing_shownearbyhouses($loc){
	global $session;
	$list = improbablehousing_getnearbyhouses($loc);
	$nlist = count($list);
	if ($nlist){
		for ($i=0; $i<$nlist; $i++){
			addnav("Nearby Dwellings");
			$house = $list[$i];
			$house = improbablehousing_canenter_house($house);
			if ($house['canenter']){
				addnav(array("Enter %s",$house['data']['name']),"runmodule.php?module=improbablehousing&op=interior&hid=".$house['id']."&rid=0");
			} else {
				addnav(array("You cannot enter %s",$house['data']['name']),"");
			}
			output_notl("`0%s`0`n`n",$house['data']['desc_exterior']);
		}
	}
	return true;
}

//Run through a bunch of conditions to see whether the player can enter a given house.  Return the whole house array, plus 'canenter' if the player can enter.
function improbablehousing_canenter_house($house){
	global $session;
	//first, we check to see if the house belongs to the player.
	if ($house['ownedby']==$session['user']['acctid']) $house['canenter']=1;
	//check to see if the house is unlocked and public.
	if (!$house['data']['locked']) $house['canenter']=1;
	//todo: keys, modulehook, clan lock, banned players
	return $house;
}

function improbablehousing_canenter_room($house,$rid){
	global $session;
	$canenter = 0;
	//first, we check to see if the house belongs to the player.
	if ($house['ownedby']==$session['user']['acctid']) $canenter=1;
	//check to see if the house is unlocked and public.
	if (!$house['data']['rooms'][$rid]['locked']) $canenter=1;
	//todo: keys, modulehook, clan lock, banned players
	return $canenter;
}

function improbablehousing_list_occupants($house,$rid){
	global $session;
	if (count($house['data']['rooms'][$rid]['occupants'])>1){
		output("Looking around, you see the following people:`n");
		foreach ($house['data']['rooms'][$rid]['occupants'] AS $acctid=>$name){
			if ($acctid!=$session['user']['acctid']){
				output_notl("`0%s`0`n",$name);
			}
		}
		output_notl("`n");
	}
}

function improbablehousing_bottomnavs($house,$rid=false){
$hid = $house['id'];
addnav("Leave");
if ($rid){
	addnav(array("Back to %s",$house['data']['rooms'][$rid]['name']),"runmodule.php?module=improbablehousing&op=interior&hid=$hid&rid=$rid");
}
addnav("D?Back to the Dwelling Entrance","runmodule.php?module=improbablehousing&op=interior&hid=$hid&rid=0");
addnav("M?Back to the Island Map","runmodule.php?module=improbablehousing&op=exit&hid=$hid");
}

//Is a particular location stakeable?  That is, are there fewer than four houses already here, and is the terrain suitable?
function improbablehousing_stakeable($loc){
	global $session;
	require_once "modules/iitems/lib/lib.php";
	if (iitems_has_item('housing_stake')){

		list($worldmapX, $worldmapY, $worldmapZ) = explode(",", $loc);
		require_once "modules/worldmapen/lib.php";
		$terrain = worldmapen_getTerrain($worldmapX,$worldmapY,$worldmapZ);
		
		if ($terrain['type']!="River" && $terrain['type']!="Ocean" && $terrain['type']!="Swamp"){
			//For now, no river, ocean or swamp houses
			$list = improbablehousing_getnearbyhouses($loc);
			$nlist = count($list);
			//todo: make this a setting
			$maxhousespersquare = 4;
			if ($nlist<$maxhousespersquare){
				addnav("Set up a new dwelling");
				addnav("Stake your claim!","runmodule.php?module=improbablehousing&op=stakeclaim");
			} else {
				addnav("Set up a new dwelling");
				addnav("You can't set up a new dwelling here because there are already too many houses.");
			}			
		}
	}
}

function improbablehousing_gethousedata($houseid){
	$sql = "SELECT ownedby,data,location FROM " . db_prefix("improbabledwellings") . " WHERE id = '$houseid'";
	//TODO: Cache and properly invalidate this query
	$result = db_query($sql);
	$row=db_fetch_assoc($result);
	$data=$row['data'];
	$data=stripslashes($data);
	$data=unserialize($data);
	$ret = array(
		"ownedby"=>$row['ownedby'],
		"id"=>$houseid,
		"data"=>$data,
		"location"=>$row['location'],
	);
	return $ret;
}

function improbablehousing_sethousedata($house){
	// debug("Setting house data: ");
	// debug($house);
	$id = $house['id'];
	$data = $house['data'];
	if (!isset($house['data']['rooms'][0]['size']) && $house['data']['buildjobs'][0]['name']!="Initial Dwelling Construction"){
		redirect("runmodule.php?module=improbablehousing&op=error&sub=manualfix&hid=".$id);
		return false;
	}
	// foreach($house['data']['rooms'] AS $rkey=>$rvals){
		// if ($rkey > 0 && $rvals['enterfrom']=='' && isset($rvals['name']) && !$house['data']['skiperror']){
			// redirect("runmodule.php?module=improbablehousing&op=error&sub=enterfrom&hid=".$id."&rid=".$rkey);
			// return false;
		// }
	// }
	// if (isset($data['skiperror'])){
		// unset($data['skiperror']);
	// }
	$data = serialize($data);
	$data = addslashes($data);
	
	//check the data can be unserialized
	$test = stripslashes($data);
	$test = unserialize($test);
	if (!isset($test['name'])){
		redirect("runmodule.php?module=improbablehousing&op=error&sub=unzip&house=".$id);
		return false;
	}
	
	if (strlen($data)>50000){
		redirect("runmodule.php?module=improbablehousing&op=error&sub=overflow&house=".$id);
		return false;
	} else {
		$sql = "UPDATE ".db_prefix("improbabledwellings")." SET data='$data' WHERE id='$id'";
		db_query($sql);
	}
}

function improbablehousing_sleeplinks($house, $rid){
	global $session;
	$hid = $house['id'];
	if (!$house['data']['rooms'][$rid]['blocksleep']){
		$sleepslots = $house['data']['rooms'][$rid]['sleepslots'];
		if (count($sleepslots)){
			foreach($sleepslots AS $slot=>$vals){
				if ($vals['occupier']){
					$acctid = $vals['occupier'];
					$sql = "SELECT name FROM ".db_prefix("accounts")." WHERE acctid='$acctid'";
					$result = db_query($sql);
					$row = db_fetch_assoc($result);
					addnav("Sleeping spaces");
					addnav(array("%s occupied by %s`0",$vals['name'],$row['name']),"");
					//do kickout navs if the player is the house owner
					if ($house['ownedby']==$session['user']['acctid']){
						addnav("Kick out Sleepers");
						addnav(array("Kick out %s`0",$row['name']),"runmodule.php?module=improbablehousing&op=sleep&sub=kickout&hid=".$house['id']."&rid=".$rid."&slot=".$slot);
					}
				} else {
					//it's an empty slot, shall we kip in it?
					addnav("Sleeping spaces");
					addnav(array("%s available`0",$vals['name']),"runmodule.php?module=improbablehousing&op=sleep&sub=start&hid=$hid&rid=$rid&slot=$slot");
				}
			}
		}
	}
}

function improbablehousing_show_decorating_management_navs($house){
	//This is the function that allows a player to write their own custom description.
	$hid = $house['id'];
	$rooms = $house['data']['rooms'];
	addnav("Decoration Management");
	foreach($rooms AS $key=>$vals){
		addnav(array("Manage %s",$vals['name']),"runmodule.php?module=improbablehousing&op=decorate&subop=start&hid=$hid&rid=$key");
	}
	addnav("Manage exterior decoration","runmodule.php?module=improbablehousing&op=decorate&subop=extdesc&hid=$hid");
}

function improbablehousing_show_decorating_jobs($house){
	//This shows links to help decorate a room
	require_once "modules/staminasystem/lib/lib.php";
	require_once "modules/iitems/lib/lib.php";
	if (iitems_has_item('toolbox_decorating')){
		$hasitem = 1;
	}
	if (get_stamina()==100){
		$hasstamina = 1;
	}
	$hid = $house['id'];
	
	$rooms = $house['data']['rooms'];
	$cost = stamina_getdisplaycost("Decorating");
	$show = 0;
	foreach($rooms AS $key=>$vals){
		if (isset($vals['dec']) && $vals['dec']['req']>$vals['dec']['done']){
			if ($hasitem && $hasstamina){
			addnav("Painting and Decorating");
			addnav(array("Decorate %s (`Q%s%%`0)",$vals['name'],$cost),"runmodule.php?module=improbablehousing&op=decorate&subop=decorate&hid=$hid&rid=$key");
			} else if ($hasitem){
				addnav("Painting and Decorating");
				addnav("You're too tired to do any sprucing up right now.","");
			} else if ($hasstamina){
				addnav("Painting and Decorating");
				addnav("You don't have the right gear to do any decorating.","");
			}
		}
	}
	if (isset($house['data']['dec']) && $house['data']['dec']['req']>$house['data']['dec']['done']){
		if ($hasitem && $hasstamina){
			addnav("Painting and Decorating");
			addnav(array("Decorate the dwelling's exterior (`Q%s%%`0)",$cost),"runmodule.php?module=improbablehousing&op=decorate&subop=decorate_exterior&hid=$hid");
		} else if ($hasitem){
			addnav("Painting and Decorating");
			addnav("You're too tired to do any sprucing up right now.","");
		} else if ($hasstamina){
			addnav("Painting and Decorating");
			addnav("You don't have the right gear to do any decorating.","");
		}
	}
}

function improbablehousing_new_build_jobs($house,$rid){
	//show new potential build jobs, including room expansion and new room addition
	//no new jobs can be added if one job is already set
	if (!isset($house['data']['buildjobs'])){
		$hid = $house['id'];
		addnav("New Build Jobs");
		if (isset($rid)){
			addnav("Increase the size of this room","runmodule.php?module=improbablehousing&op=buildjobs&hid=$hid&sub=increasesize&rid=".$rid);
		}
		addnav("Add a new Room","runmodule.php?module=improbablehousing&op=buildjobs&hid=$hid&sub=newroom&rid=".$rid);
		//maybe a modulehook here for extra build job types
	}
}

function improbablehousing_show_build_jobs($house){
	//run through the build jobs and show percentage to completion, along with navs to use the relevant item and its associated Stamina cost.
	//For easyness, don't allow the player to build if they're in Amber stamina
	$jobs = $house['data']['buildjobs'];
	require_once "modules/iitems/lib/lib.php";
	require_once "modules/staminasystem/lib/lib.php";
	$displayjobs=array();
	if (count($jobs)){
		foreach($jobs AS $key=>$vals){
			addnav(array("%s",$vals['name']));
			foreach($vals['jobs'] AS $skey=>$svals){
				$cando=1;
				$displayjobs[$vals['name']][$svals['name']]['req']=$svals['req'];
				$displayjobs[$vals['name']][$svals['name']]['done']=$svals['done'];
				//check completion
				if ($svals['completed']){
					$cando = 0;
				}
				//Check Stamina
				if (get_stamina()<100){
					$cando = 0;
					$nostam = 1;
					$displayjobs[$vals['name']][$svals['name']]['nostamina']=true;
				}
				foreach($svals['iitems'] AS $ikey=>$iitem){
					if (!iitems_has_item($ikey)){
						$displayjobs[$vals['name']][$svals['name']]['noitem']=true;
						$cando=0;
						break;
					}
				}
				if ($cando){
					$scost=0;
					foreach($svals['actions'] AS $akey=>$action){
						$scost += stamina_getdisplaycost($akey);
					}
					addnav(array("%s (`Q%s%%`0)",$svals['name'],$scost),"runmodule.php?module=improbablehousing&op=build&hid=".$house['id']."&job=".$key."&subjob=".$skey);
				}
			}
		}
	}
	if (count($displayjobs)){
		output("`b`0Current Construction Jobs`b`n");
		foreach($displayjobs AS $job=>$sub){
			output_notl("`0->%s`n",$job);
			foreach ($sub AS $sjob=>$vals){
				$jobout="<table><tr><td>";
				require_once "lib/bars.php";
				$bar = fadebar($vals['done'],$vals['req']);
				if ($vals['completed']){
					$jobout.="-->".$sjob." </td><td>".$bar."</td> ";
				} else {
					$jobout.="-->".$sjob." </td><td>".$bar."</td><td> ".$vals['done']."/".$vals['req']." ";
					if ($vals['nostamina']){
						$jobout.="(you don't have enough Stamina to do this job) ";
					}
					if ($vals['noitem']){
						$jobout.="(you don't have all the items you need to do this job) ";
					}
				}
				$jobout.="</td></tr></table>";
				rawoutput($jobout);
			}
			output_notl("`n");
		}
		output_notl("`n");
	}
	if ($nostam){
		output("You have the brains to know that doing construction work when you're anything but wide awake is an idea so bad you're not even willing to entertain it.`n`n");
	}
}

?>