<?php

function improbablehousing_getmoduleinfo(){
	$info = array(
		"name"=>"Improbable Housing",
		"version"=>"2009-11-09",
		"author"=>"Dan Hall",
		"category"=>"Improbable",
		"download"=>"",
		"prefs"=>array(
			"sleepingat"=>"Player is sleeping at...,text|nowhere",
		),
	);
	return $info;
}

function improbablehousing_install(){
	module_addhook("worldnav");
	module_addhook("village");
	module_addhook("newday");
	module_addhook("stamina-newday");
	$housing = array(
		'id'=>array('name'=>'id', 'type'=>'int(11) unsigned', 'extra'=>'auto_increment'),
		'ownedby'=>array('name'=>'ownedby', 'type'=>'int(11) unsigned'),
		'location'=>array('name'=>'location', 'type'=>'text'),
		'data'=>array('name'=>'data', 'type'=>'text'),
		'key-PRIMARY'=>array('name'=>'PRIMARY', 'type'=>'primary key',	'unique'=>'1', 'columns'=>'id'),
	);
	require_once("lib/tabledescriptor.php");
	synctable(db_prefix('improbabledwellings'), $housing, true);
	require_once("modules/staminasystem/lib/lib.php");
	install_action("Masonry",array(
		"maxcost"=>50000,
		"mincost"=>20000,
		"firstlvlexp"=>500,
		"expincrement"=>1.05,
		"costreduction"=>300,
		"class"=>"Building"
	));
	install_action("Carpentry",array(
		"maxcost"=>50000,
		"mincost"=>20000,
		"firstlvlexp"=>500,
		"expincrement"=>1.05,
		"costreduction"=>300,
		"class"=>"Building"
	));
	install_action("Decorating",array(
		"maxcost"=>50000,
		"mincost"=>20000,
		"firstlvlexp"=>500,
		"expincrement"=>1.05,
		"costreduction"=>300,
		"class"=>"Building"
	));
	return true;
}

function improbablehousing_uninstall(){
	return true;
}

function improbablehousing_dohook($hookname,$args){
	global $session;
	require("modules/improbablehousing/dohook/$hookname.php");
	return $args;
}

function improbablehousing_run(){
	global $session;
	$op = httpget("op");
	require_once("modules/improbablehousing/run/$op.php");
	page_footer();
}

?>